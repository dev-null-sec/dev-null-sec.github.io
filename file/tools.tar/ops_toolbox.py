from ipaddress import ip_address, ip_network
import os
import sys
import subprocess
import shutil

# 运维工具箱

def run_command(command, shell=False, cwd=None):#执行系统命令
    """
    执行一个系统命令，实时显示输出，并处理错误。
    这是 os.system 的一个安全、健壮的替代品。

    :param command: 命令，推荐为列表形式 (e.g., ['ls', '-l'])。
    :param shell: 仅在需要shell特性(如通配符)时设为True。
    :param cwd: 执行命令的工作目录，默认为None（当前目录）。
    :return: 成功时返回True, 失败时返回False。
    """
    try:
        cmd_str = ' '.join(command) if isinstance(command, list) else command
        print(f"[*] 正在执行: {cmd_str}")
        subprocess.run(command, shell=shell, check=True, text=True, cwd=cwd)
        return True
    except FileNotFoundError:
        print(f"[!] 错误: 命令 '{command[0] if isinstance(command, list) else command.split()[0]}' 未找到，请检查程序是否已安装。")
        return False
    except subprocess.CalledProcessError:
        print(f"[!] 命令 '{cmd_str}' 执行失败")
        return False

def check_command(command, shell=False, cwd=None):#检查系统命令
    """
    执行一个检查类命令，不抛出异常。
    :param command: 命令列表。
    :param shell: 仅在需要shell特性(如通配符)时设为True。
    :param cwd: 执行命令的工作目录，默认为None（当前目录）。
    :return: 命令成功时返回True (返回码为0), 失败时返回False。
    """
    try:
        cmd_str = ' '.join(command) if isinstance(command, list) else command
        print(f"[*] 正在检查: {cmd_str}")
        result = subprocess.run(command, shell=shell, text=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=cwd)
        return result.returncode == 0
    except FileNotFoundError:
        print(f"[!] 错误: 命令 '{command[0] if isinstance(command, list) else command.split()[0]}' 未找到。")
        return False

# ==============================================================================
# 原始功能函数 (升级 os.system -> run_command)
# ==============================================================================

def check_os():#检查系统类型和用户权限
    """检查系统类型和用户权限。"""
    if not sys.platform.startswith('linux'):
        print('当前系统不是Linux系统,请用Linux系统运行')
        sys.exit(1)

    print("正在检查用户权限...")
    if os.geteuid() != 0:
        print('当前用户不是root用户,请用root用户运行')
        sys.exit(1)
    print("权限检查通过。")

def os_info():#读取并返回操作系统信息
    """读取并返回操作系统信息。"""
    print('正在读取系统信息')
    try:
        os_release = {}
        with open('/etc/os-release') as f:
            for line in f:
                if '=' in line:
                    key, value = line.strip().split('=', 1)
                    os_release[key] = value.strip().strip('"')

        os_type = os_release.get('ID')
        os_version = os_release.get('VERSION_ID')
        os_codename = os_release.get('VERSION_CODENAME', 'unknown')
        os_name = os_release.get('PRETTY_NAME', 'unknown')
        
        print(f'系统类型: {os_type}')
        print(f'系统版本: {os_version}')
        print(f'系统代号: {os_codename}')
        print(f'系统名称: {os_name}')

        if ('centos' in os_type and os_version in ['7', '8']) or \
           ('ubuntu' in os_type and os_version in ['18.04', '20.04', '22.04']):
            print(f'当前系统为 {os_name}, 支持自动初始化')
            return os_type, os_version, os_codename, os_name
        else:
            print('当前系统不是受支持的CentOS或Ubuntu系统,不支持自动初始化')
            return None, None, None, None
    except FileNotFoundError:
        print('读取 /etc/os-release 失败，无法确定系统信息。')
        sys.exit(1)
    except Exception as e:
        print(f'读取系统信息时发生未知错误: {e}')
        sys.exit(1)

def get_network_name():#获取网络接口名称
    """获取网络接口名称。"""
    try:
        return [iface for iface in os.listdir('/sys/class/net') if iface != 'lo']
    except FileNotFoundError:
        print('读取网络接口名称失败')
        return []

def config_ip(system_type):#配置IP地址
    """配置IP地址。"""
    network_name = get_network_name()
    if not network_name:
        return
    print(f'成功检测到网络接口有: {network_name}')
    true_network_name = input("请输入网络接口名称: ")
    if true_network_name not in network_name:
        print('输入的网络接口名称不存在')
        return
    
    try:
        ip_addr = input("请输入IP地址(192.168.1.100):").strip()
        ip_address(ip_addr)
        netmask = input("请输入子网掩码(255.255.255.0):").strip()
        ip_address(netmask)
        gateway = input("请输入网关:(192.168.1.1) ").strip()
        ip_address(gateway)
        dns = input("请输入DNS服务器(默认8.8.8.8):").strip() or '8.8.8.8'
        ip_address(dns)
        dns2 = input("请输入备用DNS服务器(默认114.114.114.114):").strip() or '114.114.114.114'
        ip_address(dns2)
    except ValueError:
        print('输入的IP地址、掩码、网关或DNS格式错误')
        return

    if system_type == 'centos':
        print('正在配置CentOS系统的静态IP地址')
        config_content = f"""TYPE=Ethernet
BOOTPROTO=static
NAME={true_network_name}
DEVICE={true_network_name}
ONBOOT=yes
IPADDR={ip_addr}
NETMASK={netmask}
GATEWAY={gateway}
DNS1={dns}
DNS2={dns2}
"""
        print(config_content)
        if input('是否确认写入配置文件? [y/n] ').lower() == 'y':
            with open(f'/etc/sysconfig/network-scripts/ifcfg-{true_network_name}', 'w') as f:
                f.write(config_content)
            print('静态IP地址配置完成，正在重启网络服务...')
            run_command(['systemctl', 'restart', 'network'])
        else:
            print('已取消写入配置文件')
    elif system_type == 'ubuntu':
        netmask_cidr = ip_network(f'0.0.0.0/{netmask}', strict=False).prefixlen
        print('正在配置Ubuntu系统的静态IP地址')
        config_content = f"""network:
  version: 2
  renderer: networkd
  ethernets:
    {true_network_name}:
      dhcp4: no
      addresses: [{ip_addr}/{netmask_cidr}]
      routes:
        - to: default
          via: {gateway}
      nameservers:
        addresses: [{dns},{dns2}]
"""
        print(config_content)
        if input('是否确认写入配置文件? [y/n] ').lower() == 'y':
            with open(f'/etc/netplan/01-{true_network_name}.yaml', 'w') as f:
                f.write(config_content)
            print('静态IP地址配置完成，正在应用网络配置...')
            run_command(['netplan', 'apply'])
        else:
            print('已取消写入配置文件')
    else:
        print('当前系统不支持自动配置静态IP地址')

def disable_security(system_type):#关闭防火墙和SELinux
    """关闭防火墙。"""
    if system_type == 'centos':
        print('正在关闭CentOS系统的防火墙和SELinux')
        run_command(['systemctl', 'stop', 'firewalld'])
        run_command(['systemctl', 'disable', 'firewalld'])
        run_command(['setenforce', '0'])
        # 使用列表形式传递sed命令更安全
        run_command(['sed', '-i', 's/^SELINUX=enforcing/SELINUX=disabled/', '/etc/selinu/config'])
        print("firewalld和selinux已永久禁用")
    elif system_type == 'ubuntu':
        print('正在关闭Ubuntu系统的防火墙')
        run_command(['ufw', 'disable'])
        print("ufw已永久禁用")
    else:
        print("当前系统不支持自动关闭防火墙和SELinux")

def change_centos_repo(centos_version, centos_repo):#更换CentOS软件源
    """更换CentOS软件源。"""
    print(f'正在更换CentOS {centos_version} 系统的软件源')
    # 创建备份目录，使用os模块更稳健
    backup_dir = '/etc/yum.backup'
    os.makedirs(backup_dir, exist_ok=True)
    # 使用shell=True来处理通配符
    run_command(f'mv /etc/yum.repos.d/* {backup_dir}', shell=True)
    print(f'已备份原软件源至{backup_dir}')
    
    run_command(['wget', '-O', '/etc/yum.repos.d/CentOS-Base.repo', centos_repo])
    if centos_version == '7':
        run_command(['wget', '-O', '/etc/yum.repos.d/epel.repo', 'https://mirrors.aliyun.com/repo/epel-7.repo'])
    
    run_command(['yum', 'clean', 'all'])
    run_command(['yum', 'makecache'])
    print('CentOS系统的软件源已更换')

def change_software_source(system_type, system_version, system_name, system_codename):#更换软件源
    """更换软件源。"""
    if system_type == 'centos':
        if system_version == '7':
            change_centos_repo('7', 'https://mirrors.aliyun.com/repo/Centos-7.repo')
        elif system_version == '8':
            if 'Stream' in system_name:
                change_centos_repo('8-stream', 'https://mirrors.aliyun.com/repo/centos-stream/8/CentOS-Stream-BaseOS.repo')
            else:
                change_centos_repo('8', 'https://mirrors.aliyun.com/repo/Centos-8.repo')
    elif system_type == 'ubuntu':
        print('正在更换Ubuntu系统的软件源')
        shutil.copy('/etc/apt/sources.list', '/etc/apt/sources.list.back')
        ubuntu_repo_content = f"""deb http://mirrors.aliyun.com/ubuntu/ {system_codename} main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ {system_codename} main restricted universe multiverse
"""
        with open('/etc/apt/sources.list', 'w') as f:
            f.write(ubuntu_repo_content)
        run_command(['apt', 'update'])
        print('Ubuntu系统的软件源已更换')
    else:
        print('当前系统不支持自动更换软件源')

def install_common_software(system_type):#安装常用软件
    """安装常用软件。"""
    common_tools = ['vim', 'wget', 'net-tools', 'lrzsz', 'bash-completion']
    soft_list = ' '.join(common_tools)
    print(f'即将安装以下常用软件:{soft_list}')
    if input("即将安装以上常用软件,是否继续(y/n) ").lower() == 'y':
        if system_type == 'centos':
            print('正在安装常用软件')
            if run_command(['yum', 'install', '-y'] + common_tools):
                print('常用软件安装完成')
        elif system_type == 'ubuntu':
            print('正在安装常用软件')
            run_command(['apt', 'update', '-y'])
            if run_command(['apt', 'install', '-y'] + common_tools):
                print('常用软件安装完成')
        else:
            print('当前系统不支持自动安装常用软件')
    else:
        print('已取消安装常用软件')

def choice_web_server():#选择安装web服务
    """选择Web服务器。"""
    menu = """
==============================================
   安装web服务
==============================================
  1. 安装Apache
  2. 安装Nginx
  0. 返回上一级菜单
----------------------------------------------"""
    while True:
        subprocess.run(['clear'])
        print(menu)
        choice = input("请输入您的选择: ")
        if choice in ['1', '2', '0']:
            return {'1': 'apache', '2': 'nginx', '0': None}.get(choice)
        else:
            print('无效选择，请重新输入')
            input('\n按任意键继续...')

def install_web_server(web_type, system_type):#安装web服务
    """安装Web服务器。"""
    if web_type == 'apache':
        if system_type == 'centos':
            print('正在安装CentOS系统的Apache服务')
            run_command(['yum', 'install', '-y', 'httpd'])
            run_command(['systemctl', 'start', 'httpd'])
            run_command(['systemctl', 'enable', 'httpd'])
            print('CentOS系统的Apache服务安装完成')
        elif system_type == 'ubuntu':
            print('正在安装Ubuntu系统的Apache服务')
            run_command(['apt', 'update', '-y'])
            run_command(['apt', 'install', '-y', 'apache2'])
            run_command(['systemctl', 'start', 'apache2'])
            run_command(['systemctl', 'enable', 'apache2'])
            print('Ubuntu系统的Apache服务安装完成')
        else:
            print('当前系统不支持自动安装web服务')
    elif web_type == 'nginx':
        print('正在安装Nginx服务')
        nginx_version = input('请输入nginx版本号(例如1.24.0):')
        run_command(['yum', 'install', '-y', 'gcc', 'gcc-c++', 'pcre', 'pcre-devel', 'zlib', 'zlib-devel', 'openssl', 'openssl-devel'])
        if check_command(['id', 'nginx']):
            print('nginx用户已存在')
        else:
            run_command(['useradd', 'nginx'])
        run_command(['mkdir','-p','/usr/local/nginx'])
        run_command(['chown', 'nginx:nginx', '/usr/local/nginx'])
        if check_command(['test', '-f', f'/opt/nginx-{nginx_version}.tar.gz']):
            print('nginx文件已存在')
        else:
            run_command(['wget', f'https://nginx.org/download/nginx-{nginx_version}.tar.gz', '-O', f'/opt/nginx-{nginx_version}.tar.gz'])
        run_command(['tar', '-zxvf', f'/opt/nginx-{nginx_version}.tar.gz', '-C', '/opt/'])
        # 使用cwd参数在正确的目录中执行configure命令
        run_command([f'./configure', '--prefix=/usr/local/nginx', '--user=nginx', '--group=nginx', '--with-http_stub_status_module', '--with-http_ssl_module'], shell=True, cwd=f'/opt/nginx-{nginx_version}')
        # 直接在nginx源码目录中执行make命令
        run_command(['make'], cwd=f'/opt/nginx-{nginx_version}')
        # 直接在nginx源码目录中执行make install命令
        run_command(['make', 'install'], cwd=f'/opt/nginx-{nginx_version}')
        run_command(['ln', '-s', '/usr/local/nginx/sbin/nginx', '/usr/sbin/nginx'])
        run_command(['nginx'])
        print('=======================================')
        print(f'nginx下载目录:/opt/nginx-{nginx_version}')
        print('nginx安装目录:/usr/local/nginx')
        print('=======================================')



def install_mysql(system_type):#mysql安装
    """安装MySQL数据库。"""
    if system_type == 'centos':
        print('正在安装CentOS系统的MySQL数据库')
        #配置清华大学mysql源
        with open('/etc/yum.repos.d/mysql.repo', 'w') as f:
            f.write('''
[mysql-connectors-community]
name=MySQL Connectors Community
baseurl=https://mirrors.tuna.tsinghua.edu.cn/mysql/yum/mysql-connectors-community-el7-$basearch/
enabled=1
gpgcheck=1
gpgkey=https://repo.mysql.com/RPM-GPG-KEY-mysql-2022

[mysql-tools-community]
name=MySQL Tools Community
baseurl=https://mirrors.tuna.tsinghua.edu.cn/mysql/yum/mysql-tools-community-el7-$basearch/
enabled=1
gpgcheck=1
gpgkey=https://repo.mysql.com/RPM-GPG-KEY-mysql-2022

[mysql-5.7-community]
name=MySQL 5.7 Community Server
baseurl=https://mirrors.tuna.tsinghua.edu.cn/mysql/yum/mysql-5.7-community-el7-$basearch/
enabled=1
gpgcheck=1
gpgkey=https://repo.mysql.com/RPM-GPG-KEY-mysql-2022
''')




        run_command(['yum', 'install', '-y', 'mysql-community-server'])
        run_command(['systemctl', 'start', 'mysqld'])
        run_command(['systemctl', 'enable', 'mysqld'])
        print('CentOS系统的MySQL数据库安装完成')
    elif system_type == 'ubuntu':
        print('正在安装Ubuntu系统的MySQL数据库')
        run_command(['apt', 'update', '-y'])
        run_command(['apt', 'install', '-y', 'mysql-server'])
        run_command(['systemctl', 'start', 'mysql'])
        run_command(['systemctl', 'enable', 'mysql'])
        print('Ubuntu系统的MySQL数据库安装完成')
    else:
        print('当前系统不支持自动安装MySQL数据库')

def install_docker():#docker安装
    """docker安装"""
    run_command(['wget', '-O', 'docker_install.sh', 'https://xuanyuan.cloud/docker.sh'])
    run_command(['chmod', '+x', 'docker_install.sh'])
    run_command(['bash', 'docker_install.sh'])

def check_system():#系统巡检
    """系统巡检"""
    push_wechat = input("是否推送微信告警(y/n):")
    subprocess.run(['bash', 'check_system.sh'], stdout=open('check_system.log', 'w'))
    subprocess.run(['cat','check_system.log'])
    if push_wechat == 'y':
        # 先检查并安装兼容版本的requests库
        print("正在发送微信通知...")
        with open('check_system.log', 'r') as f:
            log_content = f.read()
        result = subprocess.run(['python3', 'wechat.py', log_content])
        if result.returncode == 0:
            print("微信通知发送成功")
        else:
            print(f"发送微信通知失败: {result.stderr}")

def show_init_menu():
    """显示初始化子菜单。"""
    menu = """
==============================================
   CentOS/Ubuntu 服务器基础初始化
==============================================
  1. 配置静态IP地址
  2. 关闭防火墙和 SELinux
  3. 更换软件源
  4. 安装常用软件
  5. 返回上一级菜单
  0. 退出
----------------------------------------------"""
    print(menu)

def choice_init_menu(system_type, system_version, system_name, system_codename):
    """初始化菜单逻辑。"""
    while True:
        subprocess.run(['clear'])
        show_init_menu()
        choice = input("请输入您的选择: ")
        if choice == '1':
            config_ip(system_type)
        elif choice == '2':
            disable_security(system_type)
        elif choice == '3':
            change_software_source(system_type, system_version, system_name, system_codename)
        elif choice == '4':
            install_common_software(system_type)
        elif choice == '5':
            break
        elif choice == '0':
            print("退出程序")
            sys.exit(0)
        else:
            print("无效选择，请重新输入")
        input('\n按任意键继续...')

def show_install_menu():
    """显示安装服务子菜单。"""
    menu = """
==============================================
   安装常用服务
==============================================
  1. 安装web服务
  2. 安装mysql
  3. 安装docker
  4. 返回上一级菜单
  0. 退出
----------------------------------------------"""
    print(menu)

def choice_install_menu(system_type):
    """安装服务子菜单逻辑。"""
    while True:
        subprocess.run(['clear'])
        show_install_menu()
        choice = input("请输入您的选择: ")
        if choice == '1':
            install_web_server(system_type)
        elif choice == '2':
            install_mysql(system_type)
        elif choice == '3':
            install_docker()
        elif choice == '4':
            break
        elif choice == '0':
            print("退出程序")
            sys.exit(0)
        else:
            print("无效选择，请重新输入")
        input('\n按任意键继续...')

def show_main_menu():
    """显示主菜单。"""
    menu = """
==============================================
   CentOS/Ubuntu 运维工具箱
==============================================
  1. 初始化系统
  2. 安装常用服务
  3. 系统日常巡检
  0. 退出
----------------------------------------------"""
    print(menu)

def main():
    """主函数。"""
    check_os()
    os_info_result = os_info()
    if os_info_result:
        system_type, system_version, system_codename, system_name = os_info_result
    else:
        print('获取系统信息失败')
        sys.exit(1)
        
    while True:
        subprocess.run(['clear'])
        show_main_menu()
        choice = input("请输入您的选择: ")
        if choice == '1':
            choice_init_menu(system_type, system_version, system_name, system_codename)
        elif choice == '2':
            choice_install_menu(system_type)
        elif choice == '3':
            check_system()
        elif choice == '0':
            print("退出程序")
            break
        else:
            print("无效选择，请重新输入")
            input('\n按任意键继续...')
            continue

        if choice != '1': 
            input('\n按任意键继续...')

if __name__ == '__main__':
    main()